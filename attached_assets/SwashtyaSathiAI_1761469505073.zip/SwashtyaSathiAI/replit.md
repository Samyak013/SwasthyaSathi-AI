# Swashtya Sathi AI - Healthcare Platform

## Project Overview
Swashtya Sathi AI is a comprehensive, AI-powered healthcare platform designed for the Indian market that connects patients, doctors, and pharmacies on a unified platform. The system features dynamic AI capabilities that analyze real patient data to provide personalized health insights, multilingual chatbot support, and secure digital record management.

## Key Features

### For Doctors
- **Patient Management**: View and manage all patients with search by name, ABHA ID, or phone
- **AI-Assisted Diagnosis**: Input symptoms and get AI-generated possible conditions, recommended tests, and urgency levels based on patient history
- **Digital Prescription System**: Create and sign digital prescriptions with unique IDs and timestamps
- **Drug Interaction Checker**: AI-powered analysis of potential drug interactions with patient's current medications
- **Dashboard Analytics**: View patient statistics, appointments, and AI-generated practice insights

### For Patients
- **Health Dashboard**: Access complete health history, prescriptions, and appointments
- **AI Health Insights**: Personalized risk assessments and recommendations based on real patient data (age, conditions, prescriptions, vitals)
- **Multilingual AI Chatbot**: Ask health questions in English, Hindi, or Marathi with context-aware responses that understand the patient's medical history
- **Smart Reminders**: Medicine and appointment reminders with intelligent scheduling
- **Health Timeline**: Visual representation of medical history and health records

### For Pharmacies
- **Prescription Verification**: Verify and manage digital prescriptions with unique signature hashes
- **Status Management**: Update prescription fulfillment status
- **Analytics Dashboard**: Track prescription volume and processing metrics

## Technology Stack

### Frontend
- React with TypeScript
- Wouter for routing
- TanStack Query for data fetching
- Shadcn UI + Tailwind CSS for styling
- Lucide React for icons

### Backend
- Express.js with TypeScript
- PostgreSQL (Neon) database
- Drizzle ORM for database operations
- Replit Auth (OpenID Connect) for authentication
- OpenAI GPT-5 for AI features

### AI Features
- **Health Insights Generator**: Analyzes patient data (age, conditions, prescriptions, vitals) to generate personalized health insights
- **Diagnosis Assistant**: Provides possible conditions and recommended tests based on symptoms and patient history
- **Drug Interaction Checker**: Analyzes potential interactions between current and new medications
- **Multilingual Chatbot**: Answers health questions in multiple languages with patient context awareness

### Security Architecture
- **Session Management**: PostgreSQL-backed sessions with secure HTTP-only cookies
- **Role-Based Access Control (RBAC)**: Middleware enforces role verification on all protected endpoints
- **One-Time Role Assignment**: Users can only select their role once during onboarding, preventing privilege escalation
- **Digital Signatures**: Prescriptions signed with unique hashes for verification
- **Protected Endpoints**: All doctor, patient, and pharmacy routes require proper authentication and role authorization

## Database Schema

### Core Tables
- **users**: Authentication and basic user information with role-based access (patient, doctor, pharmacy)
- **patient_profiles**: Detailed patient information including demographics, conditions, allergies, vitals
- **doctor_profiles**: Doctor credentials, specialization, hospital affiliation
- **prescriptions**: Digital prescriptions with medicines, diagnosis, and signature hash
- **appointments**: Doctor-patient appointments with scheduling and status
- **reminders**: Smart reminders for medicines and appointments
- **messages**: Secure doctor-patient messaging with AI translation support
- **health_records**: Comprehensive health records (lab reports, diagnoses, vitals)
- **vitals**: Latest vital signs tracking (BP, heart rate, temperature, oxygen saturation, blood sugar)

## API Endpoints

### Authentication
- `GET /api/auth/user` - Get current user
- `GET /api/login` - Start login flow
- `GET /api/logout` - Logout

### Doctor Endpoints
- `GET /api/doctor/patients` - Get all patients
- `GET /api/doctor/patients/:id` - Get patient details with full medical history
- `GET /api/doctor/prescriptions` - Get doctor's prescriptions
- `POST /api/doctor/prescriptions` - Create new prescription
- `GET /api/doctor/appointments` - Get doctor's appointments
- `POST /api/doctor/ai-diagnosis` - AI diagnosis assistance
- `POST /api/doctor/check-interactions` - Check drug interactions

### Patient Endpoints
- `GET /api/patient/prescriptions` - Get patient's prescriptions
- `GET /api/patient/appointments` - Get patient's appointments
- `GET /api/patient/reminders` - Get patient's reminders
- `GET /api/patient/records` - Get patient's health records
- `GET /api/patient/ai-insights` - Get AI-generated health insights
- `POST /api/patient/chatbot` - Chat with AI health assistant

### Pharmacy Endpoints
- `GET /api/pharmacy/prescriptions` - Get all prescriptions
- `GET /api/pharmacy/prescriptions/:id` - Verify specific prescription
- `PATCH /api/pharmacy/prescriptions/:id` - Update prescription status

## User Roles
The system supports three distinct user roles:
1. **Doctor**: Access to patient management, prescription creation, AI diagnosis tools
2. **Patient**: Access to personal health records, AI chatbot, reminders
3. **Pharmacy**: Access to prescription verification and fulfillment

## AI Integration Details

All AI features use OpenAI's GPT-5 model and are designed to analyze **real patient data** from the database:

1. **Health Insights**: Retrieves patient's actual conditions, prescriptions, vitals, and health records to generate personalized insights
2. **Chatbot**: Uses patient's real medical history to provide context-aware answers
3. **Diagnosis Assistant**: Incorporates patient's existing conditions and medications for accurate suggestions
4. **Drug Interaction Checker**: Analyzes patient's current active prescriptions against new medications

## Environment Variables
- `DATABASE_URL` - PostgreSQL connection string
- `OPENAI_API_KEY` - OpenAI API key for AI features
- `SESSION_SECRET` - Session encryption secret
- `REPLIT_DOMAINS` - Domains for Replit Auth
- `REPL_ID` - Replit application ID

## Development

### Running the Application
```bash
npm run dev
```

### Database Migrations
```bash
npm run db:push
```

## Design System
The application follows a professional healthcare design system with:
- Clean, clinical interface optimized for medical professionals
- Accessible color scheme with proper contrast ratios
- Inter font for UI, Poppins for headings, JetBrains Mono for medical IDs
- Responsive design for mobile, tablet, and desktop
- Subtle hover and active states for better UX

## Security Features
- Session-based authentication with PostgreSQL storage
- Role-based access control (RBAC)
- Digital signature hashes for prescriptions
- Secure HTTP-only cookies
- HTTPS enforcement for production

## Recent Updates
- October 25, 2025: Initial platform development completed
- Implemented comprehensive database schema with 10+ tables
- Built all core features for doctor, patient, and pharmacy dashboards
- Integrated OpenAI GPT-5 for dynamic AI features
- Created responsive, professional healthcare UI
- Added role-based authorization middleware to all protected endpoints
- Implemented secure one-time role assignment flow to prevent privilege escalation
- Created role selection page for first-time user onboarding

## Future Enhancements (Phase 2)
- Real ABHA API integration for government health record synchronization
- Real-time WebSocket for instant messaging and notifications
- File upload for lab reports and medical documents
- Advanced ML models trained on larger medical datasets
- Emergency SOS feature with location services
- Voice input for chatbot in multiple languages
- Telemedicine video consultation integration
