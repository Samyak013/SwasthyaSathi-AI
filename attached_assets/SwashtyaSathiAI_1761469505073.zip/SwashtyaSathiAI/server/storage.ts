// Blueprint reference: javascript_database, javascript_log_in_with_replit
import {
  users,
  patientProfiles,
  doctorProfiles,
  prescriptions,
  appointments,
  reminders,
  messages,
  healthRecords,
  vitals,
  type User,
  type UpsertUser,
  type PatientProfile,
  type InsertPatientProfile,
  type DoctorProfile,
  type InsertDoctorProfile,
  type Prescription,
  type InsertPrescription,
  type Appointment,
  type InsertAppointment,
  type Reminder,
  type InsertReminder,
  type Message,
  type InsertMessage,
  type HealthRecord,
  type InsertHealthRecord,
  type Vital,
  type InsertVital,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, or, sql } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  getUsersByRole(role: string): Promise<User[]>;
  
  // Patient Profile operations
  getPatientProfile(userId: string): Promise<PatientProfile | undefined>;
  createPatientProfile(profile: InsertPatientProfile): Promise<PatientProfile>;
  updatePatientProfile(userId: string, profile: Partial<InsertPatientProfile>): Promise<PatientProfile>;
  
  // Doctor Profile operations
  getDoctorProfile(userId: string): Promise<DoctorProfile | undefined>;
  createDoctorProfile(profile: InsertDoctorProfile): Promise<DoctorProfile>;
  
  // Prescription operations
  getPrescription(id: string): Promise<Prescription | undefined>;
  getPrescriptionsByPatient(patientId: string): Promise<Prescription[]>;
  getPrescriptionsByDoctor(doctorId: string): Promise<Prescription[]>;
  getAllPrescriptions(): Promise<Prescription[]>;
  createPrescription(prescription: InsertPrescription): Promise<Prescription>;
  updatePrescription(id: string, prescription: Partial<InsertPrescription>): Promise<Prescription>;
  
  // Appointment operations
  getAppointmentsByPatient(patientId: string): Promise<Appointment[]>;
  getAppointmentsByDoctor(doctorId: string): Promise<Appointment[]>;
  createAppointment(appointment: InsertAppointment): Promise<Appointment>;
  
  // Reminder operations
  getRemindersByPatient(patientId: string): Promise<Reminder[]>;
  createReminder(reminder: InsertReminder): Promise<Reminder>;
  updateReminder(id: string, reminder: Partial<InsertReminder>): Promise<Reminder>;
  
  // Message operations
  getMessagesBetween(userId1: string, userId2: string): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  
  // Health Record operations
  getHealthRecordsByPatient(patientId: string): Promise<HealthRecord[]>;
  createHealthRecord(record: InsertHealthRecord): Promise<HealthRecord>;
  
  // Vitals operations
  getLatestVitals(patientId: string): Promise<Vital | undefined>;
  createVital(vital: InsertVital): Promise<Vital>;
}

export class DatabaseStorage implements IStorage {
  // ============================================
  // User operations (mandatory for Replit Auth)
  // ============================================
  
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async getUsersByRole(role: string): Promise<User[]> {
    return await db.select().from(users).where(eq(users.role, role));
  }
  
  // ============================================
  // Patient Profile operations
  // ============================================
  
  async getPatientProfile(userId: string): Promise<PatientProfile | undefined> {
    const [profile] = await db
      .select()
      .from(patientProfiles)
      .where(eq(patientProfiles.userId, userId));
    return profile;
  }

  async createPatientProfile(profile: InsertPatientProfile): Promise<PatientProfile> {
    const [created] = await db
      .insert(patientProfiles)
      .values(profile)
      .returning();
    return created;
  }

  async updatePatientProfile(
    userId: string,
    profile: Partial<InsertPatientProfile>
  ): Promise<PatientProfile> {
    const [updated] = await db
      .update(patientProfiles)
      .set({ ...profile, updatedAt: new Date() })
      .where(eq(patientProfiles.userId, userId))
      .returning();
    return updated;
  }
  
  // ============================================
  // Doctor Profile operations
  // ============================================
  
  async getDoctorProfile(userId: string): Promise<DoctorProfile | undefined> {
    const [profile] = await db
      .select()
      .from(doctorProfiles)
      .where(eq(doctorProfiles.userId, userId));
    return profile;
  }

  async createDoctorProfile(profile: InsertDoctorProfile): Promise<DoctorProfile> {
    const [created] = await db
      .insert(doctorProfiles)
      .values(profile)
      .returning();
    return created;
  }
  
  // ============================================
  // Prescription operations
  // ============================================
  
  async getPrescription(id: string): Promise<Prescription | undefined> {
    const [prescription] = await db
      .select()
      .from(prescriptions)
      .where(eq(prescriptions.id, id));
    return prescription;
  }

  async getPrescriptionsByPatient(patientId: string): Promise<Prescription[]> {
    return await db
      .select()
      .from(prescriptions)
      .where(eq(prescriptions.patientId, patientId))
      .orderBy(desc(prescriptions.createdAt));
  }

  async getPrescriptionsByDoctor(doctorId: string): Promise<Prescription[]> {
    return await db
      .select()
      .from(prescriptions)
      .where(eq(prescriptions.doctorId, doctorId))
      .orderBy(desc(prescriptions.createdAt));
  }

  async getAllPrescriptions(): Promise<Prescription[]> {
    return await db
      .select()
      .from(prescriptions)
      .orderBy(desc(prescriptions.createdAt));
  }

  async createPrescription(prescription: InsertPrescription): Promise<Prescription> {
    const [created] = await db
      .insert(prescriptions)
      .values(prescription)
      .returning();
    return created;
  }

  async updatePrescription(
    id: string,
    prescription: Partial<InsertPrescription>
  ): Promise<Prescription> {
    const [updated] = await db
      .update(prescriptions)
      .set({ ...prescription, updatedAt: new Date() })
      .where(eq(prescriptions.id, id))
      .returning();
    return updated;
  }
  
  // ============================================
  // Appointment operations
  // ============================================
  
  async getAppointmentsByPatient(patientId: string): Promise<Appointment[]> {
    return await db
      .select()
      .from(appointments)
      .where(eq(appointments.patientId, patientId))
      .orderBy(desc(appointments.appointmentDate));
  }

  async getAppointmentsByDoctor(doctorId: string): Promise<Appointment[]> {
    return await db
      .select()
      .from(appointments)
      .where(eq(appointments.doctorId, doctorId))
      .orderBy(desc(appointments.appointmentDate));
  }

  async createAppointment(appointment: InsertAppointment): Promise<Appointment> {
    const [created] = await db
      .insert(appointments)
      .values(appointment)
      .returning();
    return created;
  }
  
  // ============================================
  // Reminder operations
  // ============================================
  
  async getRemindersByPatient(patientId: string): Promise<Reminder[]> {
    return await db
      .select()
      .from(reminders)
      .where(eq(reminders.patientId, patientId))
      .orderBy(desc(reminders.scheduledTime));
  }

  async createReminder(reminder: InsertReminder): Promise<Reminder> {
    const [created] = await db
      .insert(reminders)
      .values(reminder)
      .returning();
    return created;
  }

  async updateReminder(
    id: string,
    reminder: Partial<InsertReminder>
  ): Promise<Reminder> {
    const [updated] = await db
      .update(reminders)
      .set({ ...reminder, updatedAt: new Date() })
      .where(eq(reminders.id, id))
      .returning();
    return updated;
  }
  
  // ============================================
  // Message operations
  // ============================================
  
  async getMessagesBetween(userId1: string, userId2: string): Promise<Message[]> {
    return await db
      .select()
      .from(messages)
      .where(
        or(
          and(eq(messages.senderId, userId1), eq(messages.receiverId, userId2)),
          and(messages.senderId, userId2), eq(messages.receiverId, userId1)
        )
      )
      .orderBy(desc(messages.createdAt));
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    const [created] = await db
      .insert(messages)
      .values(message)
      .returning();
    return created;
  }
  
  // ============================================
  // Health Record operations
  // ============================================
  
  async getHealthRecordsByPatient(patientId: string): Promise<HealthRecord[]> {
    return await db
      .select()
      .from(healthRecords)
      .where(eq(healthRecords.patientId, patientId))
      .orderBy(desc(healthRecords.recordDate));
  }

  async createHealthRecord(record: InsertHealthRecord): Promise<HealthRecord> {
    const [created] = await db
      .insert(healthRecords)
      .values(record)
      .returning();
    return created;
  }
  
  // ============================================
  // Vitals operations
  // ============================================
  
  async getLatestVitals(patientId: string): Promise<Vital | undefined> {
    const [vital] = await db
      .select()
      .from(vitals)
      .where(eq(vitals.patientId, patientId))
      .orderBy(desc(vitals.recordedAt))
      .limit(1);
    return vital;
  }

  async createVital(vital: InsertVital): Promise<Vital> {
    const [created] = await db
      .insert(vitals)
      .values(vital)
      .returning();
    return created;
  }
}

export const storage = new DatabaseStorage();
