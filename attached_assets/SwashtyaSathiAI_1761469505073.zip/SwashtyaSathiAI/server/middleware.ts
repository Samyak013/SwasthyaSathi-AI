import type { RequestHandler } from "express";
import { storage } from "./storage";

// Role-based authorization middleware
export function requireRole(allowedRoles: string[]): RequestHandler {
  return async (req: any, res, next) => {
    try {
      const userId = req.user?.claims?.sub;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(401).json({ message: "User not found" });
      }

      if (!allowedRoles.includes(user.role)) {
        return res.status(403).json({ 
          message: "Forbidden - insufficient permissions",
          requiredRole: allowedRoles,
          userRole: user.role
        });
      }

      // Attach user to request for easy access
      req.currentUser = user;
      next();
    } catch (error) {
      console.error("Role check error:", error);
      res.status(500).json({ message: "Authorization check failed" });
    }
  };
}
