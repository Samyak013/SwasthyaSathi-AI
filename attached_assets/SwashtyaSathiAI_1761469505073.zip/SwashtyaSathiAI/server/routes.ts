// Blueprint reference: javascript_log_in_with_replit
import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { requireRole } from "./middleware";
import {
  generateHealthInsights,
  generateDiagnosisAssistance,
  checkDrugInteractions,
  chatbotResponse,
} from "./aiService";
import { insertPrescriptionSchema, insertAppointmentSchema, insertReminderSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // ============================================
  // Auth routes
  // ============================================
  
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Role assignment endpoint (one-time onboarding only)
  app.post('/api/auth/assign-role', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { role } = req.body;
      
      // Validate role
      if (!["patient", "doctor", "pharmacy"].includes(role)) {
        return res.status(400).json({ message: "Invalid role" });
      }
      
      // Get current user to check if role already assigned
      const currentUser = await storage.getUser(userId);
      
      // Only allow role assignment if user doesn't have a role yet (first-time onboarding)
      // This prevents privilege escalation attacks
      if (currentUser && currentUser.role) {
        return res.status(403).json({ 
          message: "Role already assigned. Cannot change role.",
          currentRole: currentUser.role
        });
      }
      
      const user = await storage.upsertUser({
        id: userId,
        role,
      });
      
      res.json(user);
    } catch (error) {
      console.error("Error assigning role:", error);
      res.status(500).json({ message: "Failed to assign role" });
    }
  });

  // ============================================
  // Doctor Routes
  // ============================================

  // Get all patients for a doctor
  app.get("/api/doctor/patients", isAuthenticated, requireRole(["doctor"]), async (req: any, res) => {
    try {
      const patients = await storage.getUsersByRole("patient");
      res.json(patients);
    } catch (error) {
      console.error("Error fetching patients:", error);
      res.status(500).json({ message: "Failed to fetch patients" });
    }
  });

  // Get single patient details
  app.get("/api/doctor/patients/:id", isAuthenticated, requireRole(["doctor"]), async (req: any, res) => {
    try {
      const patient = await storage.getUser(req.params.id);
      if (!patient) {
        return res.status(404).json({ message: "Patient not found" });
      }
      
      const profile = await storage.getPatientProfile(req.params.id);
      const prescriptions = await storage.getPrescriptionsByPatient(req.params.id);
      const vitals = await storage.getLatestVitals(req.params.id);
      const healthRecords = await storage.getHealthRecordsByPatient(req.params.id);
      
      res.json({
        ...patient,
        profile,
        prescriptions,
        vitals,
        healthRecords,
      });
    } catch (error) {
      console.error("Error fetching patient details:", error);
      res.status(500).json({ message: "Failed to fetch patient details" });
    }
  });

  // Get doctor's prescriptions
  app.get("/api/doctor/prescriptions", isAuthenticated, requireRole(["doctor"]), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const prescriptions = await storage.getPrescriptionsByDoctor(userId);
      res.json(prescriptions);
    } catch (error) {
      console.error("Error fetching prescriptions:", error);
      res.status(500).json({ message: "Failed to fetch prescriptions" });
    }
  });

  // Create prescription
  app.post("/api/doctor/prescriptions", isAuthenticated, requireRole(["doctor"]), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertPrescriptionSchema.parse({
        ...req.body,
        doctorId: userId,
      });
      
      // Generate signature hash (simplified)
      const signatureHash = Buffer.from(
        `${validatedData.doctorId}-${validatedData.patientId}-${Date.now()}`
      ).toString('base64');
      
      const prescription = await storage.createPrescription({
        ...validatedData,
        signatureHash,
      });
      
      res.json(prescription);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      console.error("Error creating prescription:", error);
      res.status(500).json({ message: "Failed to create prescription" });
    }
  });

  // Get doctor's appointments
  app.get("/api/doctor/appointments", isAuthenticated, requireRole(["doctor"]), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const appointments = await storage.getAppointmentsByDoctor(userId);
      res.json(appointments);
    } catch (error) {
      console.error("Error fetching appointments:", error);
      res.status(500).json({ message: "Failed to fetch appointments" });
    }
  });

  // AI Diagnosis Assistant
  app.post("/api/doctor/ai-diagnosis", isAuthenticated, requireRole(["doctor"]), async (req: any, res) => {
    try {
      const { symptoms, patientId } = req.body;
      
      let patientHistory = undefined;
      if (patientId) {
        const profile = await storage.getPatientProfile(patientId);
        const prescriptions = await storage.getPrescriptionsByPatient(patientId);
        
        patientHistory = {
          conditions: profile?.conditions || [],
          medications: prescriptions
            .filter(p => p.status === "active")
            .flatMap(p => {
              const meds = p.medicines as any[];
              return meds.map(m => m.name);
            }),
        };
      }
      
      const result = await generateDiagnosisAssistance({
        symptoms,
        patientHistory,
      });
      
      res.json(result);
    } catch (error) {
      console.error("Error generating diagnosis:", error);
      res.status(500).json({ message: "Failed to generate diagnosis" });
    }
  });

  // Drug Interaction Check
  app.post("/api/doctor/check-interactions", isAuthenticated, requireRole(["doctor"]), async (req: any, res) => {
    try {
      const { patientId, newMedication } = req.body;
      
      const prescriptions = await storage.getPrescriptionsByPatient(patientId);
      const currentMedications = prescriptions
        .filter(p => p.status === "active")
        .flatMap(p => {
          const meds = p.medicines as any[];
          return meds.map(m => m.name);
        });
      
      const result = await checkDrugInteractions({
        currentMedications,
        newMedication,
      });
      
      res.json(result);
    } catch (error) {
      console.error("Error checking interactions:", error);
      res.status(500).json({ message: "Failed to check interactions" });
    }
  });

  // ============================================
  // Patient Routes
  // ============================================

  // Get patient's prescriptions
  app.get("/api/patient/prescriptions", isAuthenticated, requireRole(["patient"]), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const prescriptions = await storage.getPrescriptionsByPatient(userId);
      res.json(prescriptions);
    } catch (error) {
      console.error("Error fetching prescriptions:", error);
      res.status(500).json({ message: "Failed to fetch prescriptions" });
    }
  });

  // Get patient's appointments
  app.get("/api/patient/appointments", isAuthenticated, requireRole(["patient"]), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const appointments = await storage.getAppointmentsByPatient(userId);
      res.json(appointments);
    } catch (error) {
      console.error("Error fetching appointments:", error);
      res.status(500).json({ message: "Failed to fetch appointments" });
    }
  });

  // Get patient's reminders
  app.get("/api/patient/reminders", isAuthenticated, requireRole(["patient"]), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const reminders = await storage.getRemindersByPatient(userId);
      res.json(reminders);
    } catch (error) {
      console.error("Error fetching reminders:", error);
      res.status(500).json({ message: "Failed to fetch reminders" });
    }
  });

  // Get patient's health records
  app.get("/api/patient/records", isAuthenticated, requireRole(["patient"]), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const records = await storage.getHealthRecordsByPatient(userId);
      res.json(records);
    } catch (error) {
      console.error("Error fetching health records:", error);
      res.status(500).json({ message: "Failed to fetch health records" });
    }
  });

  // AI Health Insights for patient
  app.get("/api/patient/ai-insights", isAuthenticated, requireRole(["patient"]), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      const profile = await storage.getPatientProfile(userId);
      const prescriptions = await storage.getPrescriptionsByPatient(userId);
      const vitals = await storage.getLatestVitals(userId);
      const healthRecords = await storage.getHealthRecordsByPatient(userId);
      
      // Calculate age if DOB available
      let age = undefined;
      if (profile?.dateOfBirth) {
        const dob = new Date(profile.dateOfBirth);
        const today = new Date();
        age = today.getFullYear() - dob.getFullYear();
      }
      
      const insights = await generateHealthInsights({
        age,
        conditions: profile?.conditions || [],
        prescriptions: prescriptions.filter(p => p.status === "active"),
        vitals,
        healthRecords,
      });
      
      res.json(insights);
    } catch (error) {
      console.error("Error generating insights:", error);
      res.status(500).json({ message: "Failed to generate insights" });
    }
  });

  // AI Chatbot
  app.post("/api/patient/chatbot", isAuthenticated, requireRole(["patient"]), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { question, language = "en" } = req.body;
      
      // Get patient context
      const profile = await storage.getPatientProfile(userId);
      const prescriptions = await storage.getPrescriptionsByPatient(userId);
      const healthRecords = await storage.getHealthRecordsByPatient(userId);
      
      const medications = prescriptions
        .filter(p => p.status === "active")
        .flatMap(p => {
          const meds = p.medicines as any[];
          return meds.map(m => m.name);
        });
      
      const response = await chatbotResponse({
        question,
        language,
        patientContext: {
          conditions: profile?.conditions || [],
          medications,
          recentRecords: healthRecords.slice(0, 5).map(r => r.title),
        },
      });
      
      res.json({ response });
    } catch (error) {
      console.error("Error in chatbot:", error);
      res.status(500).json({ message: "Failed to get chatbot response" });
    }
  });

  // ============================================
  // Pharmacy Routes
  // ============================================

  // Get all prescriptions for pharmacy
  app.get("/api/pharmacy/prescriptions", isAuthenticated, requireRole(["pharmacy"]), async (req: any, res) => {
    try {
      const prescriptions = await storage.getAllPrescriptions();
      res.json(prescriptions);
    } catch (error) {
      console.error("Error fetching prescriptions:", error);
      res.status(500).json({ message: "Failed to fetch prescriptions" });
    }
  });

  // Verify prescription
  app.get("/api/pharmacy/prescriptions/:id", isAuthenticated, requireRole(["pharmacy"]), async (req: any, res) => {
    try {
      const prescription = await storage.getPrescription(req.params.id);
      if (!prescription) {
        return res.status(404).json({ message: "Prescription not found" });
      }
      res.json(prescription);
    } catch (error) {
      console.error("Error verifying prescription:", error);
      res.status(500).json({ message: "Failed to verify prescription" });
    }
  });

  // Update prescription status
  app.patch("/api/pharmacy/prescriptions/:id", isAuthenticated, requireRole(["pharmacy"]), async (req: any, res) => {
    try {
      const { status } = req.body;
      const prescription = await storage.updatePrescription(req.params.id, { status });
      res.json(prescription);
    } catch (error) {
      console.error("Error updating prescription:", error);
      res.status(500).json({ message: "Failed to update prescription" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
