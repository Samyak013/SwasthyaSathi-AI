// Blueprint reference: javascript_openai
// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
import OpenAI from "openai";
import type { PatientProfile, Prescription, HealthRecord, Vital } from "@shared/schema";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// ============================================
// AI Health Insights Generator
// ============================================

export interface HealthInsightsInput {
  age?: number;
  conditions?: string[];
  prescriptions?: Prescription[];
  vitals?: Vital | null;
  healthRecords?: HealthRecord[];
}

export interface HealthInsight {
  category: string;
  severity: "low" | "medium" | "high";
  message: string;
  recommendation: string;
}

export async function generateHealthInsights(
  input: HealthInsightsInput
): Promise<HealthInsight[]> {
  try {
    const prompt = `You are a medical AI assistant analyzing patient health data. Generate personalized health insights based on the following patient information:

Age: ${input.age || "Not provided"}
Chronic Conditions: ${input.conditions?.join(", ") || "None"}
Active Prescriptions: ${input.prescriptions?.length || 0}
Recent Vitals: ${input.vitals ? JSON.stringify(input.vitals) : "Not available"}
Health Records Count: ${input.healthRecords?.length || 0}

Analyze this data and provide 2-4 health insights in JSON format. Each insight should include:
- category (string): The health aspect (e.g., "Medication Adherence", "Vital Signs", "Lifestyle")
- severity (string): "low", "medium", or "high"
- message (string): A clear, actionable message
- recommendation (string): Specific advice

Respond with valid JSON in this format:
{
  "insights": [
    {
      "category": "string",
      "severity": "low|medium|high",
      "message": "string",
      "recommendation": "string"
    }
  ]
}`;

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content:
            "You are a helpful medical AI assistant. Provide clear, actionable health insights in JSON format.",
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      response_format: { type: "json_object" },
      max_completion_tokens: 2048,
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return result.insights || [];
  } catch (error) {
    console.error("AI Health Insights error:", error);
    return [
      {
        category: "General Health",
        severity: "low",
        message: "Continue monitoring your health regularly",
        recommendation: "Schedule regular checkups with your doctor",
      },
    ];
  }
}

// ============================================
// AI Diagnosis Assistant
// ============================================

export interface DiagnosisInput {
  symptoms: string[];
  patientHistory?: {
    age?: number;
    conditions?: string[];
    medications?: string[];
  };
}

export interface DiagnosisResult {
  possibleConditions: Array<{
    condition: string;
    confidence: number;
    description: string;
  }>;
  recommendedTests: string[];
  urgency: "low" | "medium" | "high";
  disclaimer: string;
}

export async function generateDiagnosisAssistance(
  input: DiagnosisInput
): Promise<DiagnosisResult> {
  try {
    const prompt = `You are a medical AI assistant helping doctors with preliminary diagnosis. Analyze these symptoms:

Symptoms: ${input.symptoms.join(", ")}
Patient Age: ${input.patientHistory?.age || "Unknown"}
Existing Conditions: ${input.patientHistory?.conditions?.join(", ") || "None"}
Current Medications: ${input.patientHistory?.medications?.join(", ") || "None"}

Provide possible conditions, recommended tests, and urgency level in JSON format:
{
  "possibleConditions": [
    {
      "condition": "string",
      "confidence": number (0-100),
      "description": "brief explanation"
    }
  ],
  "recommendedTests": ["test1", "test2"],
  "urgency": "low|medium|high",
  "disclaimer": "This is AI-generated guidance. Always consult with a qualified healthcare professional."
}`;

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content:
            "You are a medical AI assistant providing diagnosis support for doctors. Always include disclaimers.",
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      response_format: { type: "json_object" },
      max_completion_tokens: 2048,
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return result;
  } catch (error) {
    console.error("AI Diagnosis error:", error);
    return {
      possibleConditions: [],
      recommendedTests: [],
      urgency: "medium",
      disclaimer:
        "This is AI-generated guidance. Always consult with a qualified healthcare professional.",
    };
  }
}

// ============================================
// Drug Interaction Checker
// ============================================

export interface DrugInteractionInput {
  currentMedications: string[];
  newMedication: string;
}

export interface DrugInteractionResult {
  hasInteractions: boolean;
  interactions: Array<{
    drug1: string;
    drug2: string;
    severity: "minor" | "moderate" | "severe";
    description: string;
  }>;
  recommendations: string[];
}

export async function checkDrugInteractions(
  input: DrugInteractionInput
): Promise<DrugInteractionResult> {
  try {
    const prompt = `Analyze potential drug interactions:

Current Medications: ${input.currentMedications.join(", ")}
New Medication: ${input.newMedication}

Check for interactions and respond in JSON format:
{
  "hasInteractions": boolean,
  "interactions": [
    {
      "drug1": "string",
      "drug2": "string",
      "severity": "minor|moderate|severe",
      "description": "explanation"
    }
  ],
  "recommendations": ["recommendation1", "recommendation2"]
}`;

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content:
            "You are a pharmaceutical AI expert analyzing drug interactions. Provide accurate, evidence-based information.",
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      response_format: { type: "json_object" },
      max_completion_tokens: 2048,
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return result;
  } catch (error) {
    console.error("Drug Interaction check error:", error);
    return {
      hasInteractions: false,
      interactions: [],
      recommendations: ["Consult with a pharmacist for drug interaction review"],
    };
  }
}

// ============================================
// Multilingual Health Chatbot
// ============================================

export interface ChatbotInput {
  question: string;
  language: "en" | "hi" | "mr";
  patientContext?: {
    conditions?: string[];
    medications?: string[];
    recentRecords?: string[];
  };
}

export async function chatbotResponse(input: ChatbotInput): Promise<string> {
  try {
    const languageMap = {
      en: "English",
      hi: "Hindi",
      mr: "Marathi",
    };

    const contextInfo = input.patientContext
      ? `
Patient Context:
- Conditions: ${input.patientContext.conditions?.join(", ") || "None"}
- Medications: ${input.patientContext.medications?.join(", ") || "None"}
- Recent Records: ${input.patientContext.recentRecords?.join(", ") || "None"}
`
      : "";

    const prompt = `You are a helpful health assistant. Answer the following health question in ${languageMap[input.language]}.
${contextInfo}
Question: ${input.question}

Provide a clear, empathetic answer. If the question requires medical attention, advise consulting a doctor.`;

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: `You are a compassionate health assistant fluent in ${languageMap[input.language]}. Provide accurate, helpful health information while being careful to recommend professional medical consultation when appropriate.`,
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      max_completion_tokens: 1024,
    });

    return response.choices[0].message.content || "I'm sorry, I couldn't process that request.";
  } catch (error) {
    console.error("Chatbot error:", error);
    return "I'm sorry, I'm having trouble responding right now. Please try again later.";
  }
}
