# Swashtya Sathi AI - Design Guidelines (Compact)

## Design Foundation

**System-Based Healthcare Design** - Material Design principles adapted for healthcare. Prioritizes clinical clarity, data-first presentation, and WCAG 2.1 AA compliance minimum.

**Core Principles**: Clinical clarity through visual hierarchy | Trust via consistency | Data-first design | Accessible by default

---

## Typography

### Font Stack
- **UI/Forms/Tables**: Inter (Google Fonts)
- **Medical Codes/IDs**: JetBrains Mono (Google Fonts)
- **Headers**: Poppins (Google Fonts)

### Type Scale & Usage
```css
Hero/Dashboard: Poppins Bold, text-4xl (36px), tracking-tight
Section Headers: Poppins SemiBold, text-2xl (24px)
Card Titles: Poppins Medium, text-lg (18px)
Body Text: Inter Regular, text-base (16px), leading-relaxed
Caption/Meta: Inter Regular, text-sm (14px)
Data Labels: Inter Medium, text-xs (12px), uppercase, tracking-wide
Medical IDs (ABHA/Rx): JetBrains Mono Regular, text-sm (14px)
```

**Hierarchy Rules**: Patient names use Poppins SemiBold | Medical identifiers always JetBrains Mono | Data labels uppercase Inter Medium

---

## Layout & Spacing

### Core Units
Tailwind spacing: **2, 4, 6, 8, 12, 16**

**Application**: Component padding (p-4/6/8) | Section spacing (py-12/16) | Card gaps (gap-4/6) | Form fields (space-y-4) | Data tables (p-3/4)

### Grid Patterns
- **Doctor Dashboard**: 12-col grid, collapsible sidebar (w-64)
- **Patient View**: Single column max-w-6xl, nested 2-col for cards
- **Analytics**: `grid-cols-1 md:grid-cols-2 lg:grid-cols-3`
- **Tables**: Full-width, sticky headers

### Containers
- Dashboards: Full viewport with sidebar
- Content: `max-w-7xl mx-auto px-6`
- Forms: `max-w-2xl`
- Modals: `max-w-3xl` (prescriptions), `max-w-xl` (confirmations)

---

## Components

### Navigation

**Sidebar (Doctor/Patient)**
- Fixed left (w-64), logo top, vertical menu with Heroicons (outline)
- Active: filled background + `border-l-4` accent
- Mobile: transforms to bottom nav
- Profile section bottom: avatar + name + role badge

**Top Nav (Pharmacy)**
- Horizontal: logo left, actions center, profile right
- `sticky top-0`

### Cards

**Patient Card**
```
Structure: p-4, rounded-lg border
Header: Patient name (Poppins SemiBold) + ABHA (JetBrains Mono)
Layout: Avatar left | Info center | Action right (grid)
Footer: Quick stats row (visits, conditions, Rx count)
Hover: shadow-md
```

**Medical Record Card**
- Left `border-l` accent by type (Rx/diagnosis/lab)
- Header: date badge + type + doctor
- Expandable accordion
- Footer: download/share actions

**Prescription Card**
- Document-style: header border, doctor credentials prominent
- Medicine table format
- Digital signature + QR placeholder bottom
- Print-friendly (page breaks)

**Analytics Card**
- Title + time selector
- Chart.js integration area with padding
- Legend below, data summary above

### Data Display

**Health Timeline**
```
Vertical: border-l-2 connecting line
Chronological cards attached to timeline
Date nodes: circular markers
Desktop: alternating left/right | Mobile: single column
```

**Patient List Table**
- Sticky header, sortable columns
- Row hover states, alternating treatment
- Action column right-aligned (icon buttons)
- Search bar + filter chips above
- Pagination: "Showing X of Y"

**AI Insights Panel**
- Gradient border accent, sparkles icon header
- Bulleted insights with severity indicators
- Expandable sections (risk factors, recommendations)

**Vital Signs Display**
```
Grid: 2x2 mobile, 4x1 desktop
Elements: Large value + unit | Trend arrow + % | Mini sparkline | Normal range
```

### Forms

**Digital Prescription Creator**
```
Multi-step: Progress indicator top
Step 1: Patient search dropdown
Step 2: Medicine table (add/delete rows)
  Columns: name, dosage, frequency, duration, instructions
Step 3: Notes textarea
Step 4: Review + signature
Actions: Back, Next/Submit (right-aligned)
Auto-save indicator
```

**Patient Profile Editor**
- Collapsible sections: Personal | Conditions | Allergies | Contacts
- Inline validation, error messages below fields
- Chip input for conditions/allergies (removable)

**Search & Filter**
- Sticky below nav: `w-full md:w-96` search + filter dropdown
- Active chips with clear-all

### Modals & Overlays

**AI Chatbot**
```
Position: fixed bottom-6 right-6
Size: w-96 h-[600px] (expanded)
Header: Title + language selector + minimize/close
Body: Scrollable messages (user right, AI left)
Footer: Textarea + send + mic icon
Typing indicator during processing
```

**Prescription Viewer**
- Full-screen overlay, `max-w-4xl` centered
- Print button, close (top-right), backdrop dismiss
- Scrollable content

**Notification Toast**
```
Position: top-6 right-6
Auto-dismiss: 5s, manual close option
Icon by type (medicine/appointment/alert)
Stacked when multiple, slide-in from right
```

### Interactive Elements

**AI Diagnosis Assistant**
- Expandable panel in patient view
- Multi-select symptom chips + search
- Results: confidence-scored conditions list + recommended tests
- Prominent disclaimer

**Medicine Reminder Setup**
- Toggle switches + time picker grid
- Frequency selector (daily/weekly/custom)
- Preview upcoming + notification prompt

**Pharmacy Validator**
- QR scanner UI (camera placeholder)
- Manual ID input + validation result card
- Medicine checklist + status buttons

---

## Data Visualization

**Health Analytics Dashboard**
```
Layout: 2-col desktop, stacked mobile
Charts: Line (trends) | Bar (adherence) | Pie (distribution)
Color-coded by medical significance
Interactive tooltips, date range selector
```

**Patient Statistics Cards**
- 4-card grid: large number + label + trend arrow + % change + icon

---

## Visual Assets

### Images
**Landing Page**: Full-width hero (h-screen), healthcare professional + tech image, overlay for text, CTA with `backdrop-blur-md bg-white/20`

**Dashboards**: 
- Doctor: No hero (data density priority)
- Patient: Small welcome banner (h-48, subtle illustration)
- Pharmacy: Functional header only

### Icons
- **Heroicons** (CDN): Outline for nav, solid for status
- Medical: stethoscope, pill, heart-pulse, clipboard-document
- Actions: pencil, trash, eye, download, share
- Status: check-circle, exclamation-triangle, information-circle

### Avatars
- Circular (`rounded-full`): Doctor (w-12 h-12 cards, w-16 h-16 headers) | Patient (w-10 h-10 lists, w-24 h-24 profile)
- Fallback: initials on colored background

---

## Accessibility Requirements

- **Touch targets**: 44x44px minimum
- **Forms**: Always-visible labels (no placeholder-only)
- **Errors**: Icons + text (not color alone)
- **Keyboard**: Visible focus `ring-2 ring-offset-2`
- **Skip navigation** for dashboards
- **ARIA labels** for icon-only buttons
- **Table headers** properly associated
- **Contrast**: 4.5:1 text, 3:1 UI components

---

## Responsive Strategy

### Breakpoints
- **Mobile**: Single column, stacked cards, bottom nav
- **Tablet (md:768px)**: 2-col grids, sidebar→drawer
- **Desktop (lg:1024px)**: Multi-col layouts, fixed sidebar
- **Wide (xl:1280px)**: Expanded tables, 3-4 col grids

### Key Patterns
- Sidebar → hamburger + bottom tabs (mobile)
- Tables → horizontal scroll, sticky first column
- Forms → single column (mobile)
- Charts → stack vertically (mobile)
- Modals → full-screen (mobile), centered card (desktop)

---

## Animation Rules

**Functional feedback only, NO decorative effects**

```css
Page transitions: Fade in (opacity 0→100, 200ms)
Modals: Scale + fade (scale-95→100)
Toasts: Slide in from right
Loading: Subtle pulse on skeletons
```

**DON'T**: Scroll-triggered effects, dashboard decorative animations, slow interactions