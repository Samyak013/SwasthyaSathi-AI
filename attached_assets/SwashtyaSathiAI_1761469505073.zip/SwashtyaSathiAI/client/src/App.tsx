import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { useAuth } from "@/hooks/useAuth";
import NotFound from "@/pages/not-found";
import Landing from "@/pages/landing";
import DoctorDashboard from "@/pages/doctor-dashboard";
import DoctorPatients from "@/pages/doctor-patients";
import PatientDashboard from "@/pages/patient-dashboard";
import PharmacyDashboard from "@/pages/pharmacy-dashboard";
import RoleSelection from "@/pages/role-selection";

function Router() {
  const { isAuthenticated, isLoading, user } = useAuth();

  // Show landing page for unauthenticated users
  if (isLoading || !isAuthenticated) {
    return (
      <Switch>
        <Route path="/" component={Landing} />
        <Route component={NotFound} />
      </Switch>
    );
  }

  // Show role selection if user is authenticated but hasn't selected a role yet
  // Note: Default role from DB is "patient", so we need to check more carefully
  // A truly new user will have role="patient" but no other profile data
  // For this MVP, we'll show role selection to users with default "patient" role on first login
  if (user && !user.role) {
    return <RoleSelection />;
  }

  // Authenticated routes based on user role
  const style = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  };

  return (
    <SidebarProvider style={style as React.CSSProperties}>
      <div className="flex h-screen w-full">
        <AppSidebar />
        <div className="flex flex-col flex-1 overflow-hidden">
          <header className="flex items-center justify-between p-4 border-b bg-background">
            <SidebarTrigger data-testid="button-sidebar-toggle" />
          </header>
          <main className="flex-1 overflow-auto">
            <Switch>
              {/* Doctor Routes */}
              {user?.role === "doctor" && (
                <>
                  <Route path="/" component={DoctorDashboard} />
                  <Route path="/doctor" component={DoctorDashboard} />
                  <Route path="/doctor/patients" component={DoctorPatients} />
                </>
              )}

              {/* Patient Routes */}
              {user?.role === "patient" && (
                <>
                  <Route path="/" component={PatientDashboard} />
                  <Route path="/patient" component={PatientDashboard} />
                </>
              )}

              {/* Pharmacy Routes */}
              {user?.role === "pharmacy" && (
                <>
                  <Route path="/" component={PharmacyDashboard} />
                  <Route path="/pharmacy" component={PharmacyDashboard} />
                </>
              )}

              {/* Fallback to 404 */}
              <Route component={NotFound} />
            </Switch>
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
