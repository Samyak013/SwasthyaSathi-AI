import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
} from "@/components/ui/sidebar";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  LayoutDashboard,
  Users,
  Stethoscope,
  FileText,
  Calendar,
  MessageSquare,
  Activity,
  Bell,
  Pill,
  ClipboardCheck,
  LogOut,
  Heart,
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { Link, useLocation } from "wouter";

export function AppSidebar() {
  const { user } = useAuth();
  const [location] = useLocation();

  const getInitials = (firstName?: string | null, lastName?: string | null) => {
    const first = firstName?.charAt(0) || "";
    const last = lastName?.charAt(0) || "";
    return (first + last).toUpperCase() || "U";
  };

  const doctorMenuItems = [
    {
      title: "Dashboard",
      url: "/doctor",
      icon: LayoutDashboard,
    },
    {
      title: "Patients",
      url: "/doctor/patients",
      icon: Users,
    },
    {
      title: "Prescriptions",
      url: "/doctor/prescriptions",
      icon: FileText,
    },
    {
      title: "Appointments",
      url: "/doctor/appointments",
      icon: Calendar,
    },
    {
      title: "Messages",
      url: "/doctor/messages",
      icon: MessageSquare,
    },
  ];

  const patientMenuItems = [
    {
      title: "Dashboard",
      url: "/patient",
      icon: LayoutDashboard,
    },
    {
      title: "Health Records",
      url: "/patient/records",
      icon: Activity,
    },
    {
      title: "Prescriptions",
      url: "/patient/prescriptions",
      icon: Pill,
    },
    {
      title: "Appointments",
      url: "/patient/appointments",
      icon: Calendar,
    },
    {
      title: "Reminders",
      url: "/patient/reminders",
      icon: Bell,
    },
    {
      title: "Messages",
      url: "/patient/messages",
      icon: MessageSquare,
    },
  ];

  const pharmacyMenuItems = [
    {
      title: "Dashboard",
      url: "/pharmacy",
      icon: LayoutDashboard,
    },
    {
      title: "Verify Prescription",
      url: "/pharmacy/verify",
      icon: ClipboardCheck,
    },
    {
      title: "Prescriptions",
      url: "/pharmacy/prescriptions",
      icon: FileText,
    },
  ];

  const menuItems =
    user?.role === "doctor"
      ? doctorMenuItems
      : user?.role === "pharmacy"
      ? pharmacyMenuItems
      : patientMenuItems;

  const getRoleBadgeVariant = (role?: string) => {
    switch (role) {
      case "doctor":
        return "default";
      case "pharmacy":
        return "secondary";
      default:
        return "outline";
    }
  };

  return (
    <Sidebar>
      <SidebarHeader className="p-4">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-md bg-primary flex items-center justify-center">
            <Heart className="w-5 h-5 text-primary-foreground" />
          </div>
          <div className="flex flex-col">
            <span className="font-display font-semibold text-sm">Swashtya Sathi</span>
            <span className="text-xs text-muted-foreground">AI Healthcare</span>
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Navigation</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild data-active={location === item.url}>
                    <Link href={item.url} data-testid={`link-${item.title.toLowerCase().replace(/\s+/g, '-')}`}>
                      <item.icon className="w-4 h-4" />
                      <span>{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="p-4">
        <div className="flex items-center gap-3 p-3 rounded-md bg-sidebar-accent">
          <Avatar className="w-10 h-10">
            <AvatarImage src={user?.profileImageUrl || undefined} />
            <AvatarFallback className="bg-primary text-primary-foreground text-sm">
              {getInitials(user?.firstName, user?.lastName)}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate">
              {user?.firstName} {user?.lastName}
            </p>
            <Badge variant={getRoleBadgeVariant(user?.role)} className="text-xs mt-1">
              {user?.role || "Patient"}
            </Badge>
          </div>
        </div>
        <Button
          variant="ghost"
          className="w-full justify-start mt-2"
          onClick={() => (window.location.href = "/api/logout")}
          data-testid="button-logout"
        >
          <LogOut className="w-4 h-4 mr-2" />
          Logout
        </Button>
      </SidebarFooter>
    </Sidebar>
  );
}
