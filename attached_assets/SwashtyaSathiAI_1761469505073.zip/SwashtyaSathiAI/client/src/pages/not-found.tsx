import { Button } from "@/components/ui/button";
import { FileQuestion } from "lucide-react";
import { Link } from "wouter";

export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-6">
      <div className="text-center max-w-md">
        <FileQuestion className="w-20 h-20 text-muted-foreground mx-auto mb-6 opacity-50" />
        <h1 className="font-display text-4xl font-bold mb-4">404</h1>
        <h2 className="text-xl font-semibold mb-2">Page Not Found</h2>
        <p className="text-muted-foreground mb-8">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <Link href="/">
          <Button data-testid="button-go-home">
            Go Home
          </Button>
        </Link>
      </div>
    </div>
  );
}
