import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Activity, Brain, Heart, MessageSquare, Pill, Shield, Stethoscope, Users } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <div className="relative h-screen flex items-center justify-center overflow-hidden">
        {/* Background gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-background to-accent/5" />
        
        {/* Content */}
        <div className="relative z-10 max-w-6xl mx-auto px-6 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-8">
            <Heart className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium text-primary">AI-Powered Healthcare</span>
          </div>
          
          <h1 className="font-display text-5xl md:text-6xl lg:text-7xl font-bold tracking-tight mb-6">
            Swashtya Sathi AI
          </h1>
          
          <p className="text-xl md:text-2xl text-muted-foreground mb-4 max-w-3xl mx-auto leading-relaxed">
            Your Intelligent Health Companion
          </p>
          
          <p className="text-base md:text-lg text-muted-foreground mb-12 max-w-2xl mx-auto">
            Connecting patients, doctors, and pharmacies on one secure platform with AI-driven insights, 
            multilingual support, and digital health records
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button 
              size="lg" 
              className="min-h-12 px-8 text-lg"
              onClick={() => window.location.href = "/api/login"}
              data-testid="button-get-started"
            >
              Get Started
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              className="min-h-12 px-8 text-lg"
              data-testid="button-learn-more"
            >
              Learn More
            </Button>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-24 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="font-display text-3xl md:text-4xl font-semibold mb-4">
              Comprehensive Healthcare Solutions
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Experience the future of healthcare with our integrated AI-powered platform
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="p-6 hover-elevate">
              <div className="w-12 h-12 rounded-md bg-primary/10 flex items-center justify-center mb-4">
                <Stethoscope className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-display text-lg font-semibold mb-2">Doctor Dashboard</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                Comprehensive patient management with AI-assisted diagnosis, digital prescriptions, 
                and real-time health analytics
              </p>
            </Card>

            <Card className="p-6 hover-elevate">
              <div className="w-12 h-12 rounded-md bg-primary/10 flex items-center justify-center mb-4">
                <Activity className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-display text-lg font-semibold mb-2">Patient Portal</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                Access your complete health history, get AI health insights, and receive smart reminders 
                for medications and appointments
              </p>
            </Card>

            <Card className="p-6 hover-elevate">
              <div className="w-12 h-12 rounded-md bg-primary/10 flex items-center justify-center mb-4">
                <Brain className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-display text-lg font-semibold mb-2">AI Health Insights</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                Personalized health predictions and risk assessments based on your real medical data 
                and history
              </p>
            </Card>

            <Card className="p-6 hover-elevate">
              <div className="w-12 h-12 rounded-md bg-primary/10 flex items-center justify-center mb-4">
                <MessageSquare className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-display text-lg font-semibold mb-2">Multilingual Chatbot</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                Get instant health guidance in English, Hindi, or Marathi with context-aware AI 
                that understands your medical history
              </p>
            </Card>

            <Card className="p-6 hover-elevate">
              <div className="w-12 h-12 rounded-md bg-primary/10 flex items-center justify-center mb-4">
                <Pill className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-display text-lg font-semibold mb-2">Digital Prescriptions</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                Secure digital prescriptions with automatic drug interaction checks and pharmacy 
                integration for seamless fulfillment
              </p>
            </Card>

            <Card className="p-6 hover-elevate">
              <div className="w-12 h-12 rounded-md bg-primary/10 flex items-center justify-center mb-4">
                <Shield className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-display text-lg font-semibold mb-2">ABHA Integration</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                Connect with India's Ayushman Bharat Digital Mission for unified health records 
                across all healthcare providers
              </p>
            </Card>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="py-24 px-6 bg-primary/5">
        <div className="max-w-4xl mx-auto text-center">
          <Users className="w-16 h-16 text-primary mx-auto mb-6" />
          <h2 className="font-display text-3xl md:text-4xl font-semibold mb-4">
            Join Thousands of Healthcare Professionals
          </h2>
          <p className="text-lg text-muted-foreground mb-8">
            Start your journey towards smarter, more connected healthcare today
          </p>
          <Button 
            size="lg" 
            className="min-h-12 px-8"
            onClick={() => window.location.href = "/api/login"}
            data-testid="button-join-now"
          >
            Join Now
          </Button>
        </div>
      </div>

      {/* Footer */}
      <footer className="py-12 px-6 border-t">
        <div className="max-w-7xl mx-auto text-center text-sm text-muted-foreground">
          <p className="mb-2">© 2025 Swashtya Sathi AI. All rights reserved.</p>
          <p>Empowering healthcare with artificial intelligence</p>
        </div>
      </footer>
    </div>
  );
}
