import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Users,
  FileText,
  Calendar,
  TrendingUp,
  Search,
  Stethoscope,
  Activity,
  Heart,
  AlertCircle,
} from "lucide-react";
import { Link } from "wouter";
import type { User, Prescription, Appointment } from "@shared/schema";

export default function DoctorDashboard() {
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");

  // Redirect if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [isAuthenticated, authLoading, toast]);

  const { data: patients = [] } = useQuery<User[]>({
    queryKey: ["/api/doctor/patients"],
    enabled: isAuthenticated,
  });

  const { data: prescriptions = [] } = useQuery<Prescription[]>({
    queryKey: ["/api/doctor/prescriptions"],
    enabled: isAuthenticated,
  });

  const { data: appointments = [] } = useQuery<Appointment[]>({
    queryKey: ["/api/doctor/appointments"],
    enabled: isAuthenticated,
  });

  const todayAppointments = appointments.filter((apt) => {
    const aptDate = new Date(apt.appointmentDate);
    const today = new Date();
    return (
      aptDate.toDateString() === today.toDateString() &&
      apt.status === "scheduled"
    );
  });

  const filteredPatients = patients.filter((patient) => {
    const fullName = `${patient.firstName || ""} ${patient.lastName || ""}`.toLowerCase();
    const abha = patient.abhaId?.toLowerCase() || "";
    const query = searchQuery.toLowerCase();
    return fullName.includes(query) || abha.includes(query);
  });

  const getInitials = (firstName?: string | null, lastName?: string | null) => {
    const first = firstName?.charAt(0) || "";
    const last = lastName?.charAt(0) || "";
    return (first + last).toUpperCase() || "P";
  };

  if (authLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <Activity className="w-12 h-12 text-primary animate-pulse mx-auto mb-4" />
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-8">
      {/* Welcome Header */}
      <div>
        <h1 className="font-display text-3xl font-semibold mb-2">
          Welcome back, Dr. {user?.lastName}
        </h1>
        <p className="text-muted-foreground">
          Here's an overview of your practice today
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="hover-elevate">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Patients</CardTitle>
            <Users className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="stat-total-patients">{patients.length}</div>
            <p className="text-xs text-muted-foreground mt-1">
              Active in your care
            </p>
          </CardContent>
        </Card>

        <Card className="hover-elevate">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Today's Appointments
            </CardTitle>
            <Calendar className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="stat-today-appointments">{todayAppointments.length}</div>
            <p className="text-xs text-muted-foreground mt-1">
              Scheduled consultations
            </p>
          </CardContent>
        </Card>

        <Card className="hover-elevate">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Prescriptions</CardTitle>
            <FileText className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="stat-prescriptions">{prescriptions.length}</div>
            <p className="text-xs text-muted-foreground mt-1">
              Total issued
            </p>
          </CardContent>
        </Card>

        <Card className="hover-elevate">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Success Rate</CardTitle>
            <TrendingUp className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">98.5%</div>
            <p className="text-xs text-muted-foreground mt-1">
              Patient satisfaction
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Link href="/doctor/prescriptions/new">
          <Card className="hover-elevate cursor-pointer" data-testid="card-new-prescription">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-md bg-primary/10 flex items-center justify-center">
                  <FileText className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium">New Prescription</h3>
                  <p className="text-sm text-muted-foreground">
                    Create digital prescription
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </Link>

        <Link href="/doctor/patients">
          <Card className="hover-elevate cursor-pointer" data-testid="card-view-patients">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-md bg-primary/10 flex items-center justify-center">
                  <Users className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium">View Patients</h3>
                  <p className="text-sm text-muted-foreground">
                    Manage patient records
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </Link>

        <Link href="/doctor/appointments">
          <Card className="hover-elevate cursor-pointer" data-testid="card-appointments">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-md bg-primary/10 flex items-center justify-center">
                  <Calendar className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium">Appointments</h3>
                  <p className="text-sm text-muted-foreground">
                    Manage your schedule
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </Link>
      </div>

      {/* Recent Patients */}
      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <CardTitle className="flex items-center gap-2">
              <Stethoscope className="w-5 h-5" />
              Recent Patients
            </CardTitle>
            <div className="relative w-full sm:w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search by name or ABHA ID..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
                data-testid="input-search-patients"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {filteredPatients.length === 0 ? (
            <div className="text-center py-12">
              <Users className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
              <p className="text-muted-foreground">
                {searchQuery ? "No patients found" : "No patients yet"}
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredPatients.slice(0, 5).map((patient) => (
                <Link key={patient.id} href={`/doctor/patients/${patient.id}`}>
                  <div
                    className="flex items-center gap-4 p-4 rounded-md hover-elevate border cursor-pointer"
                    data-testid={`patient-card-${patient.id}`}
                  >
                    <Avatar className="w-12 h-12">
                      <AvatarImage src={patient.profileImageUrl || undefined} />
                      <AvatarFallback className="bg-primary/10">
                        {getInitials(patient.firstName, patient.lastName)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">
                        {patient.firstName} {patient.lastName}
                      </p>
                      {patient.abhaId && (
                        <p className="text-sm text-muted-foreground font-mono">
                          ABHA: {patient.abhaId}
                        </p>
                      )}
                    </div>
                    <Badge variant="outline">
                      {patient.role === "patient" ? "Patient" : patient.role}
                    </Badge>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* AI Insights Card */}
      <Card className="border-primary/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-md bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center">
              <Heart className="w-4 h-4 text-primary-foreground" />
            </div>
            AI Health Insights
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-start gap-3 p-3 rounded-md bg-muted/50">
              <AlertCircle className="w-5 h-5 text-primary mt-0.5" />
              <div className="flex-1">
                <p className="text-sm font-medium">High Blood Pressure Trend</p>
                <p className="text-sm text-muted-foreground">
                  3 patients showing elevated BP readings this week - consider follow-up
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 rounded-md bg-muted/50">
              <AlertCircle className="w-5 h-5 text-primary mt-0.5" />
              <div className="flex-1">
                <p className="text-sm font-medium">Medication Adherence</p>
                <p className="text-sm text-muted-foreground">
                  2 patients may benefit from reminder system setup
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
