import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  Activity,
  Heart,
  Pill,
  Calendar,
  Bell,
  MessageSquare,
  TrendingUp,
  AlertCircle,
  CheckCircle,
} from "lucide-react";
import { Link } from "wouter";
import type { Prescription, Appointment, Reminder } from "@shared/schema";
import { format } from "date-fns";

export default function PatientDashboard() {
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const [showChatbot, setShowChatbot] = useState(false);

  // Redirect if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [isAuthenticated, authLoading, toast]);

  const { data: prescriptions = [] } = useQuery<Prescription[]>({
    queryKey: ["/api/patient/prescriptions"],
    enabled: isAuthenticated,
  });

  const { data: appointments = [] } = useQuery<Appointment[]>({
    queryKey: ["/api/patient/appointments"],
    enabled: isAuthenticated,
  });

  const { data: reminders = [] } = useQuery<Reminder[]>({
    queryKey: ["/api/patient/reminders"],
    enabled: isAuthenticated,
  });

  const upcomingAppointments = appointments
    .filter((apt) => {
      const aptDate = new Date(apt.appointmentDate);
      return aptDate > new Date() && apt.status === "scheduled";
    })
    .slice(0, 3);

  const activeReminders = reminders
    .filter((r) => !r.isCompleted && new Date(r.scheduledTime) > new Date())
    .slice(0, 3);

  const activePrescriptions = prescriptions.filter((p) => p.status === "active");

  if (authLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <Activity className="w-12 h-12 text-primary animate-pulse mx-auto mb-4" />
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-8">
      {/* Welcome Header */}
      <div>
        <h1 className="font-display text-3xl font-semibold mb-2">
          Welcome, {user?.firstName}!
        </h1>
        <p className="text-muted-foreground">
          Here's an overview of your health today
        </p>
      </div>

      {/* Health Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="hover-elevate">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Prescriptions</CardTitle>
            <Pill className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="stat-active-prescriptions">
              {activePrescriptions.length}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Current medications
            </p>
          </CardContent>
        </Card>

        <Card className="hover-elevate">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Upcoming Appointments</CardTitle>
            <Calendar className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="stat-upcoming-appointments">
              {upcomingAppointments.length}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Scheduled visits
            </p>
          </CardContent>
        </Card>

        <Card className="hover-elevate">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Reminders</CardTitle>
            <Bell className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="stat-pending-reminders">
              {activeReminders.length}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Upcoming reminders
            </p>
          </CardContent>
        </Card>

        <Card className="hover-elevate">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Health Score</CardTitle>
            <TrendingUp className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">85%</div>
            <Progress value={85} className="mt-2" />
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card
          className="hover-elevate cursor-pointer"
          onClick={() => setShowChatbot(true)}
          data-testid="card-ai-chatbot"
        >
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-md bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center">
                <MessageSquare className="w-6 h-6 text-primary-foreground" />
              </div>
              <div>
                <h3 className="font-medium">AI Health Assistant</h3>
                <p className="text-sm text-muted-foreground">
                  Ask health questions
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Link href="/patient/records">
          <Card className="hover-elevate cursor-pointer" data-testid="card-health-records">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-md bg-primary/10 flex items-center justify-center">
                  <Activity className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium">Health Records</h3>
                  <p className="text-sm text-muted-foreground">
                    View medical history
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </Link>

        <Link href="/patient/reminders">
          <Card className="hover-elevate cursor-pointer" data-testid="card-reminders">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-md bg-primary/10 flex items-center justify-center">
                  <Bell className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium">Reminders</h3>
                  <p className="text-sm text-muted-foreground">
                    Medicine & appointments
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </Link>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Upcoming Appointments */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              Upcoming Appointments
            </CardTitle>
          </CardHeader>
          <CardContent>
            {upcomingAppointments.length === 0 ? (
              <div className="text-center py-8">
                <Calendar className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
                <p className="text-sm text-muted-foreground">No upcoming appointments</p>
              </div>
            ) : (
              <div className="space-y-3">
                {upcomingAppointments.map((apt) => (
                  <div
                    key={apt.id}
                    className="flex items-start gap-3 p-3 rounded-md border"
                    data-testid={`appointment-${apt.id}`}
                  >
                    <div className="w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <Calendar className="w-5 h-5 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm">
                        {apt.reason || "Consultation"}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {format(new Date(apt.appointmentDate), "MMM dd, yyyy • hh:mm a")}
                      </p>
                    </div>
                    <Badge variant="outline">{apt.duration} min</Badge>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Active Reminders */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bell className="w-5 h-5" />
              Active Reminders
            </CardTitle>
          </CardHeader>
          <CardContent>
            {activeReminders.length === 0 ? (
              <div className="text-center py-8">
                <Bell className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
                <p className="text-sm text-muted-foreground">No active reminders</p>
              </div>
            ) : (
              <div className="space-y-3">
                {activeReminders.map((reminder) => (
                  <div
                    key={reminder.id}
                    className="flex items-start gap-3 p-3 rounded-md border"
                    data-testid={`reminder-${reminder.id}`}
                  >
                    <div className="w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <Bell className="w-5 h-5 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm">{reminder.title}</p>
                      <p className="text-sm text-muted-foreground">
                        {format(new Date(reminder.scheduledTime), "MMM dd, yyyy • hh:mm a")}
                      </p>
                    </div>
                    <Badge variant={reminder.type === "medicine" ? "default" : "secondary"}>
                      {reminder.type}
                    </Badge>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* AI Health Insights */}
      <Card className="border-primary/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-md bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center">
              <Heart className="w-4 h-4 text-primary-foreground" />
            </div>
            AI Health Insights
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-start gap-3 p-3 rounded-md bg-muted/50">
              <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
              <div className="flex-1">
                <p className="text-sm font-medium">Medication Adherence</p>
                <p className="text-sm text-muted-foreground">
                  You're maintaining good adherence to your medication schedule
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 rounded-md bg-muted/50">
              <AlertCircle className="w-5 h-5 text-primary mt-0.5" />
              <div className="flex-1">
                <p className="text-sm font-medium">Health Tip</p>
                <p className="text-sm text-muted-foreground">
                  Consider scheduling your annual health checkup - it's been 10 months since your last visit
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Chatbot Modal (will be enhanced) */}
      {showChatbot && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <Card className="w-full max-w-2xl">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <MessageSquare className="w-5 h-5" />
                  AI Health Assistant
                </CardTitle>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowChatbot(false)}
                  data-testid="button-close-chatbot"
                >
                  Close
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <MessageSquare className="w-16 h-16 text-primary mx-auto mb-4" />
                <p className="text-muted-foreground mb-4">
                  AI Chatbot will be integrated in the next phase
                </p>
                <p className="text-sm text-muted-foreground">
                  Ask health questions in English, Hindi, or Marathi
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
