import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Stethoscope, Heart, Pill } from "lucide-react";

export default function RoleSelection() {
  const { toast } = useToast();
  const [selectedRole, setSelectedRole] = useState<string | null>(null);

  const assignRoleMutation = useMutation({
    mutationFn: async (role: string) => {
      return await apiRequest("POST", "/api/auth/assign-role", { role });
    },
    onSuccess: () => {
      toast({
        title: "Role Assigned",
        description: "Redirecting to your dashboard...",
      });
      setTimeout(() => {
        window.location.href = "/";
      }, 1000);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to assign role",
        variant: "destructive",
      });
    },
  });

  const handleSelectRole = (role: string) => {
    setSelectedRole(role);
    assignRoleMutation.mutate(role);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-6">
      <div className="max-w-4xl w-full">
        <div className="text-center mb-12">
          <h1 className="font-display text-4xl font-bold mb-4">
            Welcome to Swashtya Sathi AI
          </h1>
          <p className="text-lg text-muted-foreground">
            Please select your role to continue
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card
            className={`cursor-pointer hover-elevate active-elevate-2 transition-all ${
              selectedRole === "doctor" ? "ring-2 ring-primary" : ""
            }`}
            onClick={() => !assignRoleMutation.isPending && handleSelectRole("doctor")}
            data-testid="card-role-doctor"
          >
            <CardHeader className="text-center">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <Stethoscope className="w-8 h-8 text-primary" />
              </div>
              <CardTitle>Doctor</CardTitle>
              <CardDescription>
                Manage patients, create prescriptions, and access AI diagnosis tools
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              {selectedRole === "doctor" && assignRoleMutation.isPending && (
                <p className="text-sm text-muted-foreground">Setting up...</p>
              )}
            </CardContent>
          </Card>

          <Card
            className={`cursor-pointer hover-elevate active-elevate-2 transition-all ${
              selectedRole === "patient" ? "ring-2 ring-primary" : ""
            }`}
            onClick={() => !assignRoleMutation.isPending && handleSelectRole("patient")}
            data-testid="card-role-patient"
          >
            <CardHeader className="text-center">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <Heart className="w-8 h-8 text-primary" />
              </div>
              <CardTitle>Patient</CardTitle>
              <CardDescription>
                Access your health records, chat with AI, and manage appointments
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              {selectedRole === "patient" && assignRoleMutation.isPending && (
                <p className="text-sm text-muted-foreground">Setting up...</p>
              )}
            </CardContent>
          </Card>

          <Card
            className={`cursor-pointer hover-elevate active-elevate-2 transition-all ${
              selectedRole === "pharmacy" ? "ring-2 ring-primary" : ""
            }`}
            onClick={() => !assignRoleMutation.isPending && handleSelectRole("pharmacy")}
            data-testid="card-role-pharmacy"
          >
            <CardHeader className="text-center">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <Pill className="w-8 h-8 text-primary" />
              </div>
              <CardTitle>Pharmacy</CardTitle>
              <CardDescription>
                Verify prescriptions and manage medicine fulfillment
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              {selectedRole === "pharmacy" && assignRoleMutation.isPending && (
                <p className="text-sm text-muted-foreground">Setting up...</p>
              )}
            </CardContent>
          </Card>
        </div>

        <p className="text-center text-sm text-muted-foreground mt-8">
          You can only select one role. Choose carefully based on your profession.
        </p>
      </div>
    </div>
  );
}
