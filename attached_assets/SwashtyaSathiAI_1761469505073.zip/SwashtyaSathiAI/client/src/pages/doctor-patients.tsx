import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Search, Users, Phone, Mail, Activity } from "lucide-react";
import { Link } from "wouter";
import type { User } from "@shared/schema";

export default function DoctorPatients() {
  const { isAuthenticated, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [isAuthenticated, authLoading, toast]);

  const { data: patients = [] } = useQuery<User[]>({
    queryKey: ["/api/doctor/patients"],
    enabled: isAuthenticated,
  });

  const filteredPatients = patients.filter((patient) => {
    const fullName = `${patient.firstName || ""} ${patient.lastName || ""}`.toLowerCase();
    const abha = patient.abhaId?.toLowerCase() || "";
    const phone = patient.phoneNumber?.toLowerCase() || "";
    const query = searchQuery.toLowerCase();
    return fullName.includes(query) || abha.includes(query) || phone.includes(query);
  });

  const getInitials = (firstName?: string | null, lastName?: string | null) => {
    const first = firstName?.charAt(0) || "";
    const last = lastName?.charAt(0) || "";
    return (first + last).toUpperCase() || "P";
  };

  if (authLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <Activity className="w-12 h-12 text-primary animate-pulse mx-auto mb-4" />
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <div>
        <h1 className="font-display text-3xl font-semibold mb-2">
          Patient Management
        </h1>
        <p className="text-muted-foreground">
          View and manage all your patients
        </p>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5" />
              All Patients ({filteredPatients.length})
            </CardTitle>
            <div className="relative w-full sm:w-80">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search by name, ABHA ID, or phone..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
                data-testid="input-search"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {filteredPatients.length === 0 ? (
            <div className="text-center py-12">
              <Users className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
              <p className="text-muted-foreground">
                {searchQuery ? "No patients found" : "No patients yet"}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4">
              {filteredPatients.map((patient) => (
                <Link key={patient.id} href={`/doctor/patients/${patient.id}`}>
                  <div
                    className="flex items-center gap-4 p-4 rounded-md hover-elevate border cursor-pointer"
                    data-testid={`patient-card-${patient.id}`}
                  >
                    <Avatar className="w-16 h-16">
                      <AvatarImage src={patient.profileImageUrl || undefined} />
                      <AvatarFallback className="bg-primary/10 text-lg">
                        {getInitials(patient.firstName, patient.lastName)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0 space-y-1">
                      <div className="flex items-center gap-2">
                        <p className="font-medium text-lg">
                          {patient.firstName} {patient.lastName}
                        </p>
                        <Badge variant="outline">
                          {patient.role === "patient" ? "Patient" : patient.role}
                        </Badge>
                      </div>
                      {patient.abhaId && (
                        <p className="text-sm text-muted-foreground font-mono flex items-center gap-2">
                          <span className="font-medium">ABHA:</span> {patient.abhaId}
                        </p>
                      )}
                      <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                        {patient.email && (
                          <span className="flex items-center gap-1">
                            <Mail className="w-3 h-3" />
                            {patient.email}
                          </span>
                        )}
                        {patient.phoneNumber && (
                          <span className="flex items-center gap-1">
                            <Phone className="w-3 h-3" />
                            {patient.phoneNumber}
                          </span>
                        )}
                      </div>
                    </div>
                    <Button variant="outline" size="sm" data-testid={`button-view-${patient.id}`}>
                      View Profile
                    </Button>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
