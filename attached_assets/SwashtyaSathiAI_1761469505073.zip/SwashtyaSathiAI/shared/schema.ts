import { sql, relations } from "drizzle-orm";
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  integer,
  boolean,
  date,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// ============================================
// SESSION & AUTH TABLES (Required for Replit Auth)
// ============================================

// Session storage table - mandatory for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table - mandatory for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  role: varchar("role", { length: 20 }), // doctor, patient, pharmacy - null for first-time users
  abhaId: varchar("abha_id", { length: 14 }).unique(), // Indian ABHA ID
  phoneNumber: varchar("phone_number", { length: 15 }),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

// ============================================
// PATIENT PROFILE
// ============================================

export const patientProfiles = pgTable("patient_profiles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  dateOfBirth: date("date_of_birth"),
  gender: varchar("gender", { length: 20 }),
  bloodGroup: varchar("blood_group", { length: 5 }),
  height: integer("height"), // in cm
  weight: integer("weight"), // in kg
  conditions: text("conditions").array().default(sql`ARRAY[]::text[]`), // chronic conditions
  allergies: text("allergies").array().default(sql`ARRAY[]::text[]`),
  emergencyContact: varchar("emergency_contact", { length: 15 }),
  address: text("address"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const patientProfileRelations = relations(patientProfiles, ({ one }) => ({
  user: one(users, {
    fields: [patientProfiles.userId],
    references: [users.id],
  }),
}));

export const insertPatientProfileSchema = createInsertSchema(patientProfiles).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertPatientProfile = z.infer<typeof insertPatientProfileSchema>;
export type PatientProfile = typeof patientProfiles.$inferSelect;

// ============================================
// DOCTOR PROFILE
// ============================================

export const doctorProfiles = pgTable("doctor_profiles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  specialization: varchar("specialization", { length: 100 }),
  licenseNumber: varchar("license_number", { length: 50 }),
  yearsOfExperience: integer("years_of_experience"),
  hospital: varchar("hospital", { length: 200 }),
  department: varchar("department", { length: 100 }),
  consultationFee: integer("consultation_fee"),
  bio: text("bio"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const doctorProfileRelations = relations(doctorProfiles, ({ one }) => ({
  user: one(users, {
    fields: [doctorProfiles.userId],
    references: [users.id],
  }),
}));

export const insertDoctorProfileSchema = createInsertSchema(doctorProfiles).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertDoctorProfile = z.infer<typeof insertDoctorProfileSchema>;
export type DoctorProfile = typeof doctorProfiles.$inferSelect;

// ============================================
// PRESCRIPTIONS
// ============================================

export const prescriptions = pgTable("prescriptions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  doctorId: varchar("doctor_id").notNull().references(() => users.id),
  patientId: varchar("patient_id").notNull().references(() => users.id),
  diagnosis: text("diagnosis"),
  medicines: jsonb("medicines").notNull(), // Array of { name, dosage, frequency, duration, instructions }
  notes: text("notes"),
  signatureHash: varchar("signature_hash", { length: 64 }), // Digital signature
  status: varchar("status", { length: 20 }).notNull().default("active"), // active, completed, cancelled
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const prescriptionRelations = relations(prescriptions, ({ one }) => ({
  doctor: one(users, {
    fields: [prescriptions.doctorId],
    references: [users.id],
    relationName: "doctor_prescriptions",
  }),
  patient: one(users, {
    fields: [prescriptions.patientId],
    references: [users.id],
    relationName: "patient_prescriptions",
  }),
}));

export const insertPrescriptionSchema = createInsertSchema(prescriptions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertPrescription = z.infer<typeof insertPrescriptionSchema>;
export type Prescription = typeof prescriptions.$inferSelect;

// ============================================
// APPOINTMENTS
// ============================================

export const appointments = pgTable("appointments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  doctorId: varchar("doctor_id").notNull().references(() => users.id),
  patientId: varchar("patient_id").notNull().references(() => users.id),
  appointmentDate: timestamp("appointment_date").notNull(),
  duration: integer("duration").notNull().default(30), // in minutes
  status: varchar("status", { length: 20 }).notNull().default("scheduled"), // scheduled, completed, cancelled
  reason: text("reason"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const appointmentRelations = relations(appointments, ({ one }) => ({
  doctor: one(users, {
    fields: [appointments.doctorId],
    references: [users.id],
    relationName: "doctor_appointments",
  }),
  patient: one(users, {
    fields: [appointments.patientId],
    references: [users.id],
    relationName: "patient_appointments",
  }),
}));

export const insertAppointmentSchema = createInsertSchema(appointments).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertAppointment = z.infer<typeof insertAppointmentSchema>;
export type Appointment = typeof appointments.$inferSelect;

// ============================================
// REMINDERS
// ============================================

export const reminders = pgTable("reminders", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  patientId: varchar("patient_id").notNull().references(() => users.id),
  type: varchar("type", { length: 30 }).notNull(), // medicine, appointment, checkup
  title: varchar("title", { length: 200 }).notNull(),
  message: text("message"),
  scheduledTime: timestamp("scheduled_time").notNull(),
  isCompleted: boolean("is_completed").notNull().default(false),
  prescriptionId: varchar("prescription_id").references(() => prescriptions.id),
  appointmentId: varchar("appointment_id").references(() => appointments.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const reminderRelations = relations(reminders, ({ one }) => ({
  patient: one(users, {
    fields: [reminders.patientId],
    references: [users.id],
  }),
  prescription: one(prescriptions, {
    fields: [reminders.prescriptionId],
    references: [prescriptions.id],
  }),
  appointment: one(appointments, {
    fields: [reminders.appointmentId],
    references: [appointments.id],
  }),
}));

export const insertReminderSchema = createInsertSchema(reminders).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertReminder = z.infer<typeof insertReminderSchema>;
export type Reminder = typeof reminders.$inferSelect;

// ============================================
// MESSAGES (Doctor-Patient Chat)
// ============================================

export const messages = pgTable("messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  senderId: varchar("sender_id").notNull().references(() => users.id),
  receiverId: varchar("receiver_id").notNull().references(() => users.id),
  message: text("message").notNull(),
  translatedText: text("translated_text"), // AI-translated version
  isRead: boolean("is_read").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const messageRelations = relations(messages, ({ one }) => ({
  sender: one(users, {
    fields: [messages.senderId],
    references: [users.id],
    relationName: "sent_messages",
  }),
  receiver: one(users, {
    fields: [messages.receiverId],
    references: [users.id],
    relationName: "received_messages",
  }),
}));

export const insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
  createdAt: true,
});

export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect;

// ============================================
// HEALTH RECORDS
// ============================================

export const healthRecords = pgTable("health_records", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  patientId: varchar("patient_id").notNull().references(() => users.id),
  recordType: varchar("record_type", { length: 50 }).notNull(), // lab_report, prescription, diagnosis, vital_signs
  title: varchar("title", { length: 200 }).notNull(),
  description: text("description"),
  data: jsonb("data"), // Flexible JSON for different record types
  recordDate: timestamp("record_date").notNull(),
  doctorId: varchar("doctor_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const healthRecordRelations = relations(healthRecords, ({ one }) => ({
  patient: one(users, {
    fields: [healthRecords.patientId],
    references: [users.id],
    relationName: "patient_health_records",
  }),
  doctor: one(users, {
    fields: [healthRecords.doctorId],
    references: [users.id],
    relationName: "doctor_health_records",
  }),
}));

export const insertHealthRecordSchema = createInsertSchema(healthRecords).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertHealthRecord = z.infer<typeof insertHealthRecordSchema>;
export type HealthRecord = typeof healthRecords.$inferSelect;

// ============================================
// VITALS (Latest vital signs for patients)
// ============================================

export const vitals = pgTable("vitals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  patientId: varchar("patient_id").notNull().references(() => users.id),
  bloodPressureSystolic: integer("bp_systolic"),
  bloodPressureDiastolic: integer("bp_diastolic"),
  heartRate: integer("heart_rate"),
  temperature: integer("temperature"), // in Fahrenheit * 10 (e.g., 986 = 98.6°F)
  oxygenSaturation: integer("oxygen_saturation"),
  bloodSugar: integer("blood_sugar"),
  recordedAt: timestamp("recorded_at").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const vitalRelations = relations(vitals, ({ one }) => ({
  patient: one(users, {
    fields: [vitals.patientId],
    references: [users.id],
  }),
}));

export const insertVitalSchema = createInsertSchema(vitals).omit({
  id: true,
  createdAt: true,
});

export type InsertVital = z.infer<typeof insertVitalSchema>;
export type Vital = typeof vitals.$inferSelect;
